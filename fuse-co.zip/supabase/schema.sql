create table categories(id uuid primary key default gen_random_uuid(),name text not null,description text,image_url text,sort int default 0);
create table products(id uuid primary key default gen_random_uuid(),sku text unique,name text not null,category_id uuid references categories,short_desc text,details text,images text[] default '{}',price numeric not null,mrp numeric,stock int default 0,featured boolean default false,collection text, active boolean default true,popularity int default 0,created_at timestamptz default now());
create table settings(key text primary key,value text);
create table orders(id text primary key,idem_key text unique not null,name text,mobile text,whatsapp text,address text,city text,state text,pin text,landmark text,notes text,subtotal numeric,delivery numeric,total numeric,status text default 'New Order',sheet_synced boolean default false,created_at timestamptz default now());
create table order_items(id bigserial primary key,order_id text references orders on delete cascade,product_id uuid,name text,qty int,price numeric);
create function dec_stock(pid uuid,q int) returns boolean language sql as $$ with u as (update products set stock=stock-q,popularity=popularity+q where id=pid and stock>=q returning 1) select exists(select 1 from u) $$;
alter table categories enable row level security; alter table products enable row level security; alter table settings enable row level security; alter table orders enable row level security; alter table order_items enable row level security;
create policy "public read" on categories for select using(true);
create policy "public read" on products for select using(active);
-- orders/order_items/settings: no public policy = only the server (service role) can touch them.
insert into settings values('whatsapp','919999999999'),('delivery_enabled','true'),('allowed_pin_prefixes','500'),('delivery_fee','80'),('free_above','2000'),('legal_notice','Sale only to buyers 18+. Only licensed, permitted (green) products. Delivery only where local law allows.');
insert into categories(name,description,sort) values('Sky Shots','Multi-shot aerial cakes',1),('Fountains','Ground fountains in gold and silver',2),('Sparklers','Hand-held, soft glow',3),('Gift Boxes','Curated festive assortments',4);
insert into products(sku,name,category_id,short_desc,price,mrp,stock,featured,collection) select 'FC-'||n,'Placeholder product '||n,(select id from categories limit 1),'Edit me in the Table Editor',499,699,50,true,'Best Sellers' from generate_series(1,4) n;
