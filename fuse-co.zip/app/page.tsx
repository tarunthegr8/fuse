import {pub} from '@/lib/db';import {Add} from '@/components/Shop';
export const dynamic='force-dynamic';
export default async function Home(){const db=pub();
 const [{data:cats},{data:ps},{data:st}]=await Promise.all([db.from('categories').select().order('sort'),db.from('products').select().order('popularity',{ascending:false}),db.from('settings').select().eq('key','legal_notice')]);
 const P=ps||[];const sec=(t:string,l:any[])=>l.length?<section id={t==='All products'?'shop':undefined}><h2>{t}</h2><div className="grid">{l.map(p=><article key={p.id}><div className="img" style={p.images?.[0]?{backgroundImage:`url(${p.images[0]})`}:undefined}/><h3>{p.name}</h3><p>{p.short_desc}</p><div className="pr"><b>₹{p.price}</b>{p.mrp>p.price&&<s>₹{p.mrp}</s>}{p.mrp>p.price&&<em>{Math.round(100-p.price/p.mrp*100)}% off</em>}</div><small>{p.stock>0?(p.stock<10?`Only ${p.stock} left`:'In stock'):'Out of stock'}</small><Add p={p} disabled={p.stock<1}/></article>)}</div></section>:null;
 return <main><header className="hero"><div className="burst"><i/><i/><i/></div><h1>This Diwali,<br/>make it spark.</h1><p>Explore our collection and make your celebrations memorable.</p><a className="btn" href="#shop">Shop now</a><a className="ghost" href="#cats">Explore collection</a></header>
 <section id="cats"><h2>Shop by category</h2><div className="cats">{cats?.map(c=><a key={c.id} href="#shop"><b>{c.name}</b><span>{c.description}</span></a>)}</div></section>
 {sec('Best Sellers',P.filter(p=>p.collection==='Best Sellers'))}{sec('New Arrivals',P.filter(p=>p.collection==='New Arrivals'))}{sec('All products',P)}
 <section id="about"><h2>About FUSE.CO</h2><p>Replace with your store story, licence details and contact information.</p></section>
 <section id="faq"><h2>FAQ</h2><p><b>Is my order confirmed on submit?</b> No. We confirm on WhatsApp after checking stock and delivery eligibility.</p></section>
 <footer>{st?.[0]?.value}</footer></main>}
