import {NextResponse as R} from 'next/server';import {z} from 'zod';import {admin} from '@/lib/db';
const S=z.object({key:z.string().min(8),name:z.string().trim().min(2),mobile:z.string().regex(/^[6-9]\d{9}$/),whatsapp:z.string().regex(/^[6-9]\d{9}$/).or(z.literal('')).optional(),address:z.string().trim().min(5),city:z.string().trim().min(2),state:z.string().trim().min(2),pin:z.string().regex(/^[1-9]\d{5}$/),landmark:z.string().optional(),notes:z.string().optional(),age_ok:z.literal(true),items:z.array(z.object({id:z.string().uuid(),qty:z.number().int().min(1).max(50)})).min(1).max(40)});
export async function POST(req:Request){
 const p=S.safeParse(await req.json().catch(()=>null)); if(!p.success) return R.json({error:'Please check your details.',fields:p.error.flatten().fieldErrors},{status:400});
 const d=p.data,db=admin();
 const dup=await db.from('orders').select('id,total').eq('idem_key',d.key).maybeSingle();
 const st:Record<string,string>=Object.fromEntries(((await db.from('settings').select()).data||[]).map(r=>[r.key,r.value]));
 const wa=(o:string,t:number,items:string)=>`https://wa.me/${st.whatsapp}?text=${encodeURIComponent(`*New FUSE.CO order ${o}*\n${d.name}\nMobile: ${d.mobile}\nWhatsApp: ${d.whatsapp||d.mobile}\n${d.address}, ${d.city}, ${d.state} - ${d.pin}\n\n${items}\n*Total: ₹${t}*\nNotes: ${d.notes||'-'}`)}`;
 if(dup.data) return R.json({orderId:dup.data.id,total:dup.data.total,wa:wa(dup.data.id,dup.data.total,'(items: see dashboard)')});
 if(st.delivery_enabled!=='true'||!st.allowed_pin_prefixes.split(',').some(x=>d.pin.startsWith(x.trim()))) return R.json({error:'Sorry, we cannot deliver to this PIN code.'},{status:422});
 const {data:prods}=await db.from('products').select().in('id',d.items.map(i=>i.id)).eq('active',true);
 const lines=d.items.map(i=>{const pr=prods?.find(x=>x.id===i.id);return pr&&pr.stock>=i.qty?{...i,name:pr.name as string,price:Number(pr.price)}:null});
 if(lines.some(l=>!l)) return R.json({error:'An item is out of stock or unavailable. Please review your cart.'},{status:409});
 const L=lines as {id:string;qty:number;name:string;price:number}[];
 const sub=L.reduce((s,l)=>s+l.price*l.qty,0),del=sub>=Number(st.free_above)?0:Number(st.delivery_fee),total=sub+del;
 const id='FC'+Date.now().toString(36).toUpperCase()+Math.random().toString(36).slice(2,5).toUpperCase();
 const ins=await db.from('orders').insert({id,idem_key:d.key,name:d.name,mobile:d.mobile,whatsapp:d.whatsapp||d.mobile,address:d.address,city:d.city,state:d.state,pin:d.pin,landmark:d.landmark,notes:d.notes,subtotal:sub,delivery:del,total});
 if(ins.error) return R.json({error:'Could not save your order. Please try again.'},{status:500});
 await db.from('order_items').insert(L.map(l=>({order_id:id,product_id:l.id,name:l.name,qty:l.qty,price:l.price})));
 for(const l of L) await db.rpc('dec_stock',{pid:l.id,q:l.qty});
 try{const r=await fetch(process.env.SHEETS_WEBHOOK_URL!,{method:'POST',body:JSON.stringify({secret:process.env.SHEETS_SECRET,id,date:new Date().toISOString(),...d,items:L.map(l=>`${l.name} x${l.qty} @₹${l.price}`).join('; '),qty:L.reduce((s,l)=>s+l.qty,0),sub,del,total,status:'New Order'})});if(r.ok)await db.from('orders').update({sheet_synced:true}).eq('id',id)}catch{}
 return R.json({orderId:id,total,wa:wa(id,total,L.map(l=>`${l.name} x${l.qty} = ₹${l.price*l.qty}`).join('\n'))});
}
