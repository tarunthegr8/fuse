import './globals.css';import {Fraunces,Hanken_Grotesk} from 'next/font/google';import {CartButton} from '@/components/Shop';
const d=Fraunces({subsets:['latin'],variable:'--d'}),b=Hanken_Grotesk({subsets:['latin'],variable:'--b'});
export const metadata={title:'FUSE.CO | Light Up Your Diwali',description:'Premium festive fireworks.'};
export default function L({children}:{children:React.ReactNode}){return <html lang="en" className={d.variable+' '+b.variable}><body><nav><a href="/" className="logo">FUSE<i>.</i>CO</a><span><a href="#shop">Shop</a><a href="#about">About</a><a href="#faq">FAQ</a><CartButton/></span></nav>{children}</body></html>}
