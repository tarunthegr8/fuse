'use client';
import {useEffect,useState,useSyncExternalStore} from 'react';
type L={id:string;name:string;price:number;qty:number};
let cart:L[]=[];let loaded=false;const subs=new Set<()=>void>();
const load=()=>{if(!loaded&&typeof window!=='undefined'){loaded=true;try{cart=JSON.parse(localStorage.getItem('fuse')||'[]')}catch{}}};
const set=(c:L[])=>{cart=c;localStorage.setItem('fuse',JSON.stringify(c));subs.forEach(f=>f())};
const EMPTY:L[]=[];
const useCart=()=>useSyncExternalStore(f=>{subs.add(f);return()=>{subs.delete(f)}},()=>{load();return cart},()=>EMPTY);
export function Add({p,disabled}:{p:{id:string;name:string;price:number};disabled?:boolean}){
 const [ok,setOk]=useState(false);
 return <button className="btn" disabled={disabled} onClick={()=>{load();const c=cart.find(x=>x.id===p.id);set(c?cart.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x):[...cart,{id:p.id,name:p.name,price:Number(p.price),qty:1}]);setOk(true);setTimeout(()=>setOk(false),900)}}>{disabled?'Sold out':ok?'Added ✓':'Add to cart'}</button>}
export function CartButton(){
 const c=useCart(),[open,setOpen]=useState(false),[step,setStep]=useState<'cart'|'form'|'done'>('cart'),[err,setErr]=useState(''),[busy,setBusy]=useState(false),[res,setRes]=useState<any>(null),[key]=useState(()=>crypto.randomUUID());
 const n=c.reduce((s,x)=>s+x.qty,0),sub=c.reduce((s,x)=>s+x.qty*x.price,0);
 async function submit(e:React.FormEvent<HTMLFormElement>){e.preventDefault();if(busy)return;setBusy(true);setErr('');const f=Object.fromEntries(new FormData(e.currentTarget));
  const r=await fetch('/api/orders',{method:'POST',body:JSON.stringify({...f,key,age_ok:f.age_ok==='on',items:c.map(x=>({id:x.id,qty:x.qty}))})});const j=await r.json();setBusy(false);
  if(!r.ok)return setErr(j.error+(j.fields?' Check: '+Object.keys(j.fields).join(', '):''));setRes(j);set([]);setStep('done')}
 return <><button className="cartbtn" onClick={()=>{setStep('cart');setOpen(true)}} aria-label="Open cart">Cart <b>{n}</b></button>
 {open&&<div className="scrim" onClick={()=>setOpen(false)}><aside onClick={e=>e.stopPropagation()}>
  <button className="x" onClick={()=>setOpen(false)}>Close</button>
  {step==='cart'&&<><h2>Your cart</h2>{!c.length&&<p>Nothing here yet. Pick something that sparks.</p>}
   {c.map(x=><div className="row" key={x.id}><span>{x.name}<br/>₹{x.price}</span><span><button onClick={()=>set(cart.map(y=>y.id===x.id?{...y,qty:y.qty-1}:y).filter(y=>y.qty>0))}>−</button> {x.qty} <button onClick={()=>set(cart.map(y=>y.id===x.id?{...y,qty:y.qty+1}:y))}>+</button> <button onClick={()=>set(cart.filter(y=>y.id!==x.id))}>Remove</button></span></div>)}
   {!!c.length&&<><p className="tot">Subtotal ₹{sub}</p><button className="btn" onClick={()=>setStep('form')}>Checkout</button></>}</>}
  {step==='form'&&<form onSubmit={submit}><h2>Delivery details</h2>
   <input name="name" placeholder="Full name" required/><input name="mobile" placeholder="Mobile (10 digits)" inputMode="numeric" pattern="[6-9][0-9]{9}" required/><input name="whatsapp" placeholder="WhatsApp (if different)" pattern="[6-9][0-9]{9}"/>
   <input name="address" placeholder="House no, street, locality" required/><input name="city" placeholder="City" required/><input name="state" placeholder="State" required/><input name="pin" placeholder="PIN code" inputMode="numeric" pattern="[1-9][0-9]{5}" required/><input name="landmark" placeholder="Landmark (optional)"/><input name="notes" placeholder="Instructions (optional)"/>
   <label className="chk"><input type="checkbox" name="age_ok" required/> I am 18+ and these products are legal to receive and use at my address.</label>
   <p className="tot">Subtotal ₹{sub}. Delivery is added on submit.</p>{err&&<p className="err">{err}</p>}<button className="btn" disabled={busy}>{busy?'Submitting…':'Submit order request'}</button></form>}
  {step==='done'&&res&&<><h2>Order request received</h2><p>Order ID <b>{res.orderId}</b>, total ₹{res.total}.</p><p><b>Not confirmed yet.</b> Send the details on WhatsApp so we can confirm availability and delivery.</p><a className="btn" href={res.wa} target="_blank">Send on WhatsApp</a></>}
 </aside></div>}</>}
