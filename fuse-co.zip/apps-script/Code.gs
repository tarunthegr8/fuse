// Sheet > Extensions > Apps Script > paste > Deploy as Web app (Execute as me, access: Anyone). Add Script Property SECRET = same as SHEETS_SECRET.
function doPost(e){var d=JSON.parse(e.postData.contents);
 if(d.secret!==PropertiesService.getScriptProperties().getProperty('SECRET'))return ContentService.createTextOutput('no');
 var s=SpreadsheetApp.getActiveSheet();
 if(s.getLastRow()==0)s.appendRow(['Order ID','Date','Name','Mobile','WhatsApp','Address','City','State','PIN','Products','Qty','Subtotal','Delivery','Total','Status']);
 s.appendRow([d.id,d.date,d.name,d.mobile,d.whatsapp||d.mobile,d.address,d.city,d.state,d.pin,d.items,d.qty,d.sub,d.del,d.total,d.status]);
 return ContentService.createTextOutput('ok');}
